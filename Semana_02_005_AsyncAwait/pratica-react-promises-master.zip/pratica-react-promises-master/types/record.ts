export type Record = {
  [key: string]: string | number | symbol
};